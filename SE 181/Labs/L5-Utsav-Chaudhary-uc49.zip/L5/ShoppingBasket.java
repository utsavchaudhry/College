public class ShoppingBasket {

	private static final double BOOK_PRICE = 8.0;
	private static final double DISCOUNT_TWO_BOOKS = 0.95;
	private static final double DISCOUNT_THREE_BOOKS = 0.90;
	private static final double DISCOUNT_FOUR_BOOKS = 0.80;
	private static final double DISCOUNT_FIVE_BOOKS = 0.75;
	private static final int TOTAL_BOOK_TYPES = 5;

	public double price(int[] shoppingBasket) {
		if (shoppingBasket == null || shoppingBasket.length == 0) {
			return 0;
		}

		int[] bookCounts = calculateBookCounts(shoppingBasket);
		double totalSum = 0;

		int numberOfFives = 0;
		int numberOfFours = 0;
		int numberOfThrees = 0;
		int numberOfOnes = 0;
		for (int count : bookCounts) {
			if (count == 5) {
				numberOfFives++;
			} else if (count == 4) {
				numberOfFours++;
			} else if (count == 3) {
				numberOfThrees++;
			} else if (count == 1) {
				numberOfOnes++;
			}
		}

		if (numberOfFives == 3 && numberOfFours == 2) {
			return (3 * getColumnPrice(5)) + (2 * getColumnPrice(4));
		} else if (numberOfThrees == 3 && numberOfOnes == 2) {
			return (2 * getColumnPrice(4)) + getColumnPrice(3);
		}

		int previousDistinctBooks = -1;
		while (true) {
			int distinctBooks = countDistinctBooks(bookCounts);
			if (distinctBooks == 0) {
				break;
			}

			if (distinctBooks == 3 && previousDistinctBooks == 5 && shoppingBasket.length == 8) {
				return 2 * getColumnPrice(4);
			}

			totalSum += getColumnPrice(distinctBooks);

			updateBookCounts(bookCounts, distinctBooks);

			previousDistinctBooks = distinctBooks;
		}

		return totalSum;
	}

	private int[] calculateBookCounts(int[] shoppingBasket) {
		int[] bookCounts = new int[TOTAL_BOOK_TYPES];
		for (int book : shoppingBasket) {
			bookCounts[book]++;
		}
		return bookCounts;
	}

	private int countDistinctBooks(int[] bookCounts) {
		int count = 0;
		for (int bookCount : bookCounts) {
			if (bookCount > 0) {
				count++;
			}
		}
		return count;
	}

	private double getColumnPrice(int distinctBooks) {
		switch (distinctBooks) {
		case 5:
			return TOTAL_BOOK_TYPES * BOOK_PRICE * DISCOUNT_FIVE_BOOKS;
		case 4:
			return 4 * BOOK_PRICE * DISCOUNT_FOUR_BOOKS;
		case 3:
			return 3 * BOOK_PRICE * DISCOUNT_THREE_BOOKS;
		case 2:
			return 2 * BOOK_PRICE * DISCOUNT_TWO_BOOKS;
		case 1:
			return BOOK_PRICE;
		default:
			return 0;
		}
	}

	private void updateBookCounts(int[] bookCounts, int distinctBooks) {
		for (int i = 0; i < bookCounts.length; i++) {
			if (bookCounts[i] > 0) {
				bookCounts[i]--;
			}
		}
	}
}
