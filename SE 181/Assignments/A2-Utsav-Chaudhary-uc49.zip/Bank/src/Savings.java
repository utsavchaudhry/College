
public class Savings extends Account {

	public Savings(double apr) {
		super(apr, 0);
	}

}
