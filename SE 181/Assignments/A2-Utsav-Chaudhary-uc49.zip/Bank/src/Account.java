
public abstract class Account {

	private double balance;
	private double apr;

	public Account(double apr, double balance) {
		this.balance = balance;
		this.apr = apr;
	}

	public double getAPR() {
		return apr;
	}

	public double getBalance() {
		return balance;
	}

	public void deposit(double amount) {
		balance += amount;
	}

	public void withdraw(double amount) {
		if (balance > amount) {
			balance -= amount;
		} else {
			balance = 0;
		}
	}
}
