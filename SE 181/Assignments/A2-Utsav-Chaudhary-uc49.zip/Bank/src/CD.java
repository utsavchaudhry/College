
public class CD extends Account {

	public CD(double apr, double balance) {
		super(apr, balance);
	}
}
