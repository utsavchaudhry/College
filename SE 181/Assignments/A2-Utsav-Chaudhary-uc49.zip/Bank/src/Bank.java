import java.util.HashMap;
import java.util.Map;

public class Bank {

	private Map<Integer, Account> accounts;

	public Bank() {
		accounts = new HashMap<>();
	}

	public int getTotalAccountsCount() {
		return accounts.size();
	}

	public int getNextUID() {
		return 10000000 + accounts.size();
	}

	public void addAccount(int uID, Account account) {
		accounts.put(uID, account);
	}

	public Account getAccount(int uID) {
		return accounts.get(uID);
	}

	public void deposit(int uid, double amount) {
		accounts.get(uid).deposit(amount);
	}

	public void withdraw(int uid, double amount) {
		accounts.get(uid).withdraw(amount);
	}
}
