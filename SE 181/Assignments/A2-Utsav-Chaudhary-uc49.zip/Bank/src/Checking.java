
public class Checking extends Account {

	public Checking(double apr) {
		super(apr, 0);
	}
}
