import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class CDTest {

	@Test
	void starting_balance_equal_to_supplied_amount() {
		CD cd = new CD(5, 1000);
		assertEquals(cd.getBalance(), 1000);
	}

}
