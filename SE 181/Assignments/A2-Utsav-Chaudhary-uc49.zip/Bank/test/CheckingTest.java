import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class CheckingTest {

	@Test
	void balance_initially_0() {
		Checking checking = new Checking(5);
		assertEquals(checking.getBalance(), 0);
	}

}
