import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class BankTest {

	Bank bank;

	@BeforeEach
	void setup() {
		bank = new Bank();
	}

	@Test
	void no_account_initially() {
		assertEquals(bank.getTotalAccountsCount(), 0);
	}

	@Test
	void when_an_account_added_bank_has_1_account() {
		bank.addAccount(bank.getNextUID(), new CD(5, 1000));
		assertEquals(bank.getTotalAccountsCount(), 1);
	}

	@Test
	void when_2_accounts_added_bank_has_2_accounts() {
		bank.addAccount(bank.getNextUID(), new CD(5, 1000));
		bank.addAccount(bank.getNextUID(), new Savings(5));
		assertEquals(bank.getTotalAccountsCount(), 2);
	}

	@Test
	void correct_account_retrieved() {
		int uid = bank.getNextUID();
		CD cd = new CD(5, 1000);
		bank.addAccount(uid, cd);
		assertEquals(bank.getAccount(uid), cd);
	}

	@Test
	void correct_account_gets_money_on_deposit() {
		int uid = bank.getNextUID();
		Savings savings = new Savings(5);
		bank.addAccount(uid, savings);
		bank.deposit(uid, 1000);
		assertEquals(savings.getBalance(), 1000);
	}

	@Test
	void correct_account_loses_money_on_withdrawal() {
		int uid = bank.getNextUID();
		Savings savings = new Savings(5);
		bank.addAccount(uid, savings);
		bank.deposit(uid, 1000);
		bank.withdraw(uid, 500);
		assertEquals(savings.getBalance(), 500);
	}

	@Test
	void depositing_twice_works_as_expected() {
		int uid = bank.getNextUID();
		Savings savings = new Savings(5);
		bank.addAccount(uid, savings);
		bank.deposit(uid, 1000);
		bank.deposit(uid, 1000);
		assertEquals(savings.getBalance(), 2000);
	}

	@Test
	void withdrawing_twice_works_as_expected() {
		int uid = bank.getNextUID();
		Savings savings = new Savings(5);
		bank.addAccount(uid, savings);
		bank.deposit(uid, 1000);
		bank.withdraw(uid, 500);
		bank.withdraw(uid, 200);
		assertEquals(savings.getBalance(), 300);
	}

}
