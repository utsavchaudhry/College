import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class AccountTest {

	Savings savings;

	@BeforeEach
	void setup() {
		savings = new Savings(5);
	}

	@Test
	void apr_equal_to_supplied_value() {
		savings = new Savings(8.5);
		assertEquals(savings.getAPR(), 8.5);
	}

	@Test
	void balance_increases_by_amount_deposited() {
		savings.deposit(1000);
		assertEquals(savings.getBalance(), 1000);
	}

	@Test
	void balance_decreases_by_amount_withdrawn() {
		savings.deposit(1000);
		savings.withdraw(500);
		assertEquals(savings.getBalance(), 500);
	}

	@Test
	void balance_cant_go_below_0_when_withdrawing() {
		savings.deposit(1000);
		savings.withdraw(1200);
		assertEquals(savings.getBalance(), 0);
	}

	@Test
	void depositing_twice_works_as_expected() {
		savings.deposit(1000);
		savings.deposit(1000);
		assertEquals(savings.getBalance(), 2000);
	}

	@Test
	void withdrawing_twice_works_as_expected() {
		savings.deposit(1000);
		savings.withdraw(100);
		savings.withdraw(100);
		assertEquals(savings.getBalance(), 800);
	}

}
