import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class SavingsTest {

	@Test
	void balance_initially_0() {
		Savings savings = new Savings(5);
		assertEquals(savings.getBalance(), 0);
	}

}
